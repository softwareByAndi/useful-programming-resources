## Developing

install the dependencies using `npm install`, and then start a development server:

```bash
npm i
npm run dev

# or to start the server and open the app in a new browser tab
npm i
npm run dev -- --open
```


## If your project doesn't work:
1. follow these steps to create a new svelte project and initialize tailwind: https://tailwindcss.com/docs/guides/sveltekit

2. copy the `/src` folder into your new repo
3. open a terminal in your new project and follow the #Developing steps above


# create-svelte

Everything you need to build a Svelte project, powered by [`create-svelte`](https://github.com/sveltejs/kit/tree/master/packages/create-svelte).
https://github.com/sveltejs/kit/tree/master/packages/create-svelte
