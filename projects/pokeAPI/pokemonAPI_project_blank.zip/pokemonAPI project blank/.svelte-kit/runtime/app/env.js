export { prerendering } from '../env.js';

/**
 * @type {import('$app/env').browser}
 */
const browser = !import.meta.env.SSR;

/**
 * @type {import('$app/env').dev}
 */
const dev = __SVELTEKIT_DEV__;

export { browser, dev };
