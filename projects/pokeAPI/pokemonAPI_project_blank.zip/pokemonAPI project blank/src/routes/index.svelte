<script lang="js">
  import {onMount} from "svelte";

  const api_url_base = 'https://pokeapi.co/api/v2/';
  let pokemonName = "";
  let pokemonDetails = [
      {
        title: "",
        entries: [
          {
            name: "", // empty string if no value
            value: 0 || "", // empty string if no value
            description: "", // empty string if no valaue
          }
        ]
      }
    ];

  async function query(url = "") {
    // FIXME: add API query logic here...
    return undefined || {
      height: 10,
      weight: 100
    };
  }

  async function queryPokemonData(_pokemonName = "") {
    const api_url = ""; // FIXME: get the proper url
    const _pokeName = pokemonName;
    pokemonName = 'Querying for ' + pokemonName + "... ";
    const data = await query(api_url);
    if (!data) {
      pokemonName = `'${_pokeName}' not found`;
      pokemonDetails = [];
      return;
    }
    // FIXME: populate me with the pokemon details!
    pokemonDetails = [
      {
        title: "Physical Attributes",
        entries: [
          {
            name: 'height' || "", // optional name of entry
            value: data.height || "", // this is likely to be empty...
            description: "this is the height of the pokemon..." || ""
              // FIXME: tip: there's sometimes a url somewhere here.
              // query the data from the given url, and look at the 'effect_entries' property
          },
          {
            name: 'weight', // optional name of entry
            value: data.weight,
            description: "wow, he's really heavy!"
          }
        ]
      },
    ]
    pokemonName = _pokeName
  }

  // You can ignore me... 

  async function handleFormSubmission(event) {
    event.preventDefault();
    const [_input] = await event.target.querySelectorAll("#searchInput")
    if (!_input?.value) pokemonName = "Error: invalid input..."
    await queryPokemonData(_input.value)
  }

  async function toggleElement(id="", idClass="", toggleClass="") {
    const ele_description = document.getElementById(id)
    const show_description = ele_description?.classList.contains(toggleClass);
    await Promise.all(
      [...(await document.getElementsByClassName(idClass))]
        .map(async ele => await ele.classList.add(toggleClass))
    );
    if (show_description) ele_description?.classList.remove(toggleClass);
  }

  async function toggleDescription(event) {
    event.preventDefault();
    await Promise.all([
      toggleElement(`${event.target.id}-description`, 'description', 'hidden'),
      toggleElement(`${event.target.id}`, 'entry-name', 'border-none')
    ])
  }

  onMount(() => {
    pokemonName = "persian";
    queryPokemonData(pokemonName);
  })

</script>

<style>
  .h1 {
    @apply text-2xl font-bold tracking-wider;
  }

  .details-block {
    @apply flex items-center gap-[15px];
  }

  .details-block h2 {
    @apply capitalize text-lg text-white font-bold tracking-wider;
  }
</style>

<div class="m-0 p-[40px] min-h-screen">
  <h1 class="text-4xl text-blue-800 font-extrabold tracking-wide text-center mb-[40px]">PokéAPI Search:</h1>

  <form on:submit={handleFormSubmission} class="flex justify-center items-center gap-[10px] w-[60%] mx-auto">
    <label for="searchInput" class="h1 text-white">Pokémon: </label>
    <input bind:value={pokemonName} id="searchInput" class="h-[2rem] flex-grow rounded-md px-[10px]">
    <button type="submit" class="bg-blue-100 rounded-md py-[4px] px-[10px] hover:bg-blue-600 hover:text-white">Search
    </button>
  </form>

  <div class="h-[50px]"></div>

  <div class="flex flex-col justify-center items-center">
    <p class="h1 text-white capitalize">{pokemonName}{pokemonName && ':'}</p>

    <div class="flex flex-col gap-y-[30px] pt-[30px] border-solid border-white border-t-2 ">
      {#each pokemonDetails as details_category}
        <div class="details-block flex-wrap">
          <h2>{`${details_category.title}:`}</h2>
          {#each details_category.entries as category_entry}
            <div class="flex flex-nowrap gap-[3px]">
              <p on:click={toggleDescription}
                 id="{category_entry.name}"
                 class="entry-name border-none border-solid border-white border-2 rounded-md box-border px-[5px]"
              >
                {category_entry.name}{category_entry.value && ":"}
              </p>
              <p class="font-bold">{category_entry.value}</p>
              <div id="{category_entry.name}-description"
                   class="description hidden flex flex-wrap p-[20px]
                          fixed left-1/2 top-[100vh] -translate-y-full -translate-x-1/2 w-full max-w-[820px]"
              >
                <div class="bg-neutral-100 rounded-md w-full py-[20px] px-[10px] h-[300px]
                  overflow-y-scroll whitespace-pre-wrap">
                  <h3 class="font-bold capitalize">{category_entry.name}:</h3>
                  <p>{category_entry.description}</p>
                </div>
              </div>
            </div>
          {/each}
        </div>
      {/each}
    </div>
  </div>

  <div class="h-[400px]"></div>
</div>




