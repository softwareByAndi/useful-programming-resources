<script>
  import "../tailwind.css";
</script>

<div class="max-w-[860px] min-h-screen bg-blue-400 m-0 mx-auto">
  <slot/>
</div>
